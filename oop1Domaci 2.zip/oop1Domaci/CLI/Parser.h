#pragma once
#include <string>
#include "Structures.h"
#include <vector>
using namespace std;

class Parser
{
public:
  vector<ParsedCommand> parseCommands(const string &input);
  string getError();
  void resetError();

private:
  static bool isLetter(char c);
  static string error;
};
