#pragma once
#include <string>
#include <exception>
using namespace std;

enum class ErrorType
{
    LEXICAL,
    SYNTAX,
    SEMANTIC,
    RUNTIME,
    OS
};

class Error : public exception
{
    ErrorType type;
    string message;
    int position;

public:
    Error(ErrorType t, const string &msg, int pos = -1)
        : type(t), message(msg), position(pos) {}

    const char *what() const noexcept override
    {
        return message.c_str();
    }

    ErrorType getType() const { return type; }
    int getPosition() const { return position; }
};