#include "Interpreter.h"
#include "CLIParser.h"
#include <iostream>
#include <vector>
#include "Error.h"
using namespace std;
string Interpreter::prompt = "$";

// pronalazi i izrvsava komandu
void Interpreter::executeCommand(Invocation &inv)
{
    if (commandMap.find(inv.command) != commandMap.end())
    {
        (commandMap[inv.command])->execute(inv);
    }
    else
    {
        throw Error(ErrorType::SYNTAX, "Error: command not found", -1);
    }
}

// pomocna funkcija za debug ispis parsed komandi
void output(const vector<ParsedCommand> &parsed)
{
    for (int i = 0; i < parsed.size(); i++)
        cout << parsed[i].command << " option: " << parsed[i].options[0] << " argument:" << parsed[i].args[0] << "  i: " << parsed.size() << endl;
}

// glavna petlja interpretera
void Interpreter::activate()
{
    isActive = true;
    string input, err = "";
    vector<ParsedCommand> parsed;
    while (isActive)
    {
        try
        {
            cout << prompt;
            if (!getline(cin, input) || input == "exit")
                break;
            parsed = parser.parseCommands(input);
            vector<Invocation> invs(parsed.size());
            streamHandler.connectPipeline(invs, parsed); // povezivanje komandi preko stream handlera
            for (int i = 0; i < invs.size(); i++)        // izvrsavanje komandi redom
                executeCommand(invs[i]);
        }
        catch (const Error &e)
        {
            cout << e.what();
            if (e.getPosition() >= 0)
                cout << " at position " << e.getPosition();
            cout << endl;
            continue;
        }
    }
    isActive = false;
}

// dodavanje nove komande u mapu
void Interpreter::addCommand(const string &command, unique_ptr<Command> commandPointer)
{
    commandMap[command] = move(commandPointer);
}
// podesavanje prompt teksta
void Interpreter::setPrompt(string p)
{
    prompt = p;
}
