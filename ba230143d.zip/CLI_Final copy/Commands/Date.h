#pragma once
#include "Command.h"
#include "../Structures.h"
using namespace std;

class Date : public Command
{
public:
    void execute(Invocation &inv) override;
};