#include "Echo.h"
#include "../Error.h"
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;

void Echo::execute(Invocation &inv)
{
    // provera da li je izlazni stream ispravan
    if (!inv.out || !inv.out->good())
    {
        throw Error(ErrorType::RUNTIME, "echo - output stream is not valid or already closed", -1);
    }
    // echo ne sme da ima opcije
    if (inv.options && !inv.options->empty())
        throw Error(ErrorType::SYNTAX, "echo - echo does not take options", -1);

    // provera da li je prosledjeno previse argumenata
    if (inv.args && inv.args->size() > 1)
        throw Error(ErrorType::SYNTAX, "echo - too many arguments", -1);

    // provera da li je navedeno vise ulaza sto nije dozvoljeno
    if (inv.in != &cin && inv.args && inv.args->size())
        throw Error(ErrorType::SEMANTIC, "echo - multiple inputs specified for echo", -1);

    // ako nema argumenata cita se sa ulaza
    if (!inv.args || inv.args->empty())
    {
        ostringstream buffer;
        string line;
        while (getline(*inv.in, line))
        {
            buffer << line;
            if (!inv.in->eof())
                buffer << '\n';
        }
        (*inv.out) << buffer.str();
        if (inv.out == &cout && inv.in != &cin)
        {
            cout << endl;
        }
        inv.out->flush();
        if (inv.in == &cin)
        {
            cin.clear();
        }
        return;
    }

    // ako je prosledjen string ispisuje se direktno
    if ((*inv.args)[0][0] != '*')
    {
        (*inv.out) << (*inv.args)[0];
        if (inv.out == &cout)
        {
            cout << endl;
        }
        inv.out->flush();
        return;
    }
    // ako je prosledjen fajl ispisi njegov sadrzaj
    else
    {
        string filename = (*inv.args)[0].substr(1);
        ifstream file(filename, ios::in | ios::binary);
        if (!file.is_open())
            throw Error(ErrorType::OS, "echo - cannot open file: " + filename, -1);
        char ch;
        while (file.get(ch))
        {
            (*inv.out) << ch;
        }
        if (inv.out == &cout)
        {
            cout << endl;
        }
        inv.out->flush();
        return;
    }
}