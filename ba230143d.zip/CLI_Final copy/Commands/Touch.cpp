#include "../Error.h"
#include "Touch.h"
#include <fstream>
#include <iostream>
using namespace std;

void Touch::execute(Invocation &inv)
{
    // touch ne sme da ima opcije
    if (inv.options && !inv.options->empty())
    {
        throw Error(ErrorType::SYNTAX, "touch - touch does not take options");
    }
    // ulazna redirekcija nije dozvoljena
    if (inv.in && inv.in != &cin)
    {
        throw Error(ErrorType::SEMANTIC, "touch - touch does not take input redirection");
    }
    // izlazna redirekcija nije dozvoljena
    if (inv.out && inv.out != &cout)
    {
        throw Error(ErrorType::SEMANTIC, "touch - touch does not take output redirection");
    }
    // mora postojati bar jedan argument
    if (!inv.args || inv.args->empty())
    {
        throw Error(ErrorType::SYNTAX, "touch - missing argument: filename");
    }
    // svaki argument mora poceti sa *
    for (const auto &arg : *inv.args)
    {
        if (arg.empty() || arg[0] != '*')
        {
            throw Error(ErrorType::SYNTAX, "touch - invalid argument for touch: " + arg);
        }
    }
    // za svaki argument proveri da li fajl postoji ili ga napravi
    for (const auto &arg : *inv.args)
    {
        string filename = arg.substr(1);
        if (filename.empty())
        {
            throw Error(ErrorType::SYNTAX, "touch - invalid argument for touch: " + arg);
        }
        ifstream f(filename);
        if (f.good())
        {
            throw Error(ErrorType::SEMANTIC, "touch - file already exists: " + filename);
        }
        ofstream file(filename, ios::app);
        if (!file)
        {
            throw Error(ErrorType::OS, "touch - cannot create file: " + filename);
        }
    }
}