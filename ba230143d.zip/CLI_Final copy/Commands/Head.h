#pragma once
#include "Command.h"
#include <string>
class Head : public Command
{
public:
    void execute(Invocation &inv) override;
};