#include "Date.h"
#include "../Error.h"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

void Date::execute(Invocation &inv)
{
    // provera da li su prosledjeni argumenti ili opcije sto nije dozvoljeno
    if (inv.args && !inv.args->empty())
        throw Error(ErrorType::SYNTAX, "date - date does not take arguments", -1);
    if (inv.options && !inv.options->empty())
        throw Error(ErrorType::SYNTAX, "date - date does not take options", -1);

    // dohvatanje trenutnog vremena iz system clock
    auto now = chrono::system_clock::now();
    time_t now_time = chrono::system_clock::to_time_t(now);

    // pretvaranje vremena u lokalno
    tm *local_tm = std::localtime(&now_time);
    if (!local_tm)
        throw Error(ErrorType::RUNTIME, "date - cannot get local date", -1);

    // formatiranje i ispis datuma u obliku godina mesec dan
    (*inv.out) << put_time(local_tm, "%Y-%m-%d");
    inv.out->flush();
    if (inv.out == &cout)
        cout << endl;
}