#pragma once
#include "Command.h"
#include "../Interpreter.h"
using namespace std;

class Prompt : public Command
{
public:
    void execute(Invocation &inv) override;
};