#pragma once
#include "Command.h"
#include "../Structures.h"
using namespace std;

class Wc : public Command
{
public:
    void execute(Invocation &inv) override;
};