#include "Rm.h"
#include "../Error.h"
#include <cstdio> // za std::remove

void Rm::execute(Invocation &inv)
{
    // rm ne sme da ima opcije
    if (inv.options && !inv.options->empty())
        throw Error(ErrorType::SYNTAX, "rm - rm does not take options");

    // mora postojati tacno jedan argument
    if (!inv.args || inv.args->size() != 1)
        throw Error(ErrorType::SYNTAX, "rm - missing or too many arguments for rm");

    // argument mora poceti sa *
    string arg = (*inv.args)[0];

    if (arg.empty() || arg[0] != '*')
        throw Error(ErrorType::SYNTAX, "rm - invalid argument for rm: " + arg);

    string filename = arg.substr(1);

    // pokusaj brisanja fajla
    if (std::remove(filename.c_str()) != 0)
        throw Error(ErrorType::OS, "rm - cannot remove file: " + filename);
}
