#include "Prompt.h"
#include "../Error.h"
#include <string>
using namespace std;

void Prompt::execute(Invocation &inv)
{
    if ((*inv.args).size() != 1)
        throw Error(ErrorType::SYNTAX, "prompt - prompt takes one argument");
    Interpreter::setPrompt((*inv.args)[0]);
    return;
}