#include "Truncate.h"
#include "../Error.h"
#include <fstream>

// truncate ne sme da ima opcije
void Truncate::execute(Invocation &inv)
{
    if (inv.options && !inv.options->empty())
        throw Error(ErrorType::SYNTAX, "truncate - truncate does not take options");

    // mora postojati tacno jedan argument
    if (!inv.args || inv.args->size() != 1)
        throw Error(ErrorType::SYNTAX, "truncate - missing or too many arguments for truncate");

    string arg = (*inv.args)[0];

    // argument mora poceti sa *
    if (arg.empty() || arg[0] != '*')
        throw Error(ErrorType::SYNTAX, "truncate - invalid argument for truncate: " + arg);

    string filename = arg.substr(1);
    // otvaranje fajla u trunc rezimu brise sadrzaj
    ofstream file(filename, ios::trunc);
    if (!file.is_open())
        throw Error(ErrorType::OS, "truncate - cannot open file: " + filename);

    file.close();
}