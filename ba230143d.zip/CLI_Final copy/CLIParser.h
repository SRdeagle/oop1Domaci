#pragma once
#include <string>
#include "Structures.h"
#include <vector>
using namespace std;

class CLIParser
{
public:
  vector<ParsedCommand> parseCommands(const string &input);

private:
  static bool isLetter(char c);
  bool handleQuotation(char c, State &state, string &buffer, ParsedCommand &cmd, int i);
  bool handleDash(char c, State &state, string &buffer, ParsedCommand &cmd, int &i, const string &line);
  bool HandleRest(char c, State &state, string &buffer, ParsedCommand &cmd, int &i, const string &line);
  bool finalizeCommand(State &state, string &buffer, ParsedCommand &cmd);
  bool validatePipeline(vector<ParsedCommand> &cmds);
};
